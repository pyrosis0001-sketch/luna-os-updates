# LUNA OS R2 — LUNA Shell

R2 replaces the R1 Welcome screen with a minimal desktop shell on the
**labwc** Wayland compositor. See `docs/adr/0001-r2-compositor.md` for the
compositor decision and `STATUS.md` for verified results.

## Components (separate processes)

| Component | Kind | Role |
| --- | --- | --- |
| `luna-session` | bash, tty1 login | Starts labwc, hands the Wayland environment to the systemd user manager, returns to the console, blocks automatic restarts after 3 compositor failures in 120 s |
| `luna-session-start` | sh, run by labwc | Imports the environment and starts `luna-session.target` |
| `luna-shell` | Qt/QML, user service | Home (background layer), Dock (top layer + exclusive zone), app launcher, window overview, AI panel (overlay layers) |
| `luna-toplevel` | C, child of the shell | Bridges `zwlr_foreign_toplevel_manager_v1` to JSON lines (list, activate, minimize, maximize, close) |
| `luna-settings` | Qt/QML, on demand | Settings: network, Bluetooth, sound, display, appearance, input, time, power, account, apps, storage, about |
| `luna-mode` | sh | Desktop/Tablet policy state; manual switching only in R2 |
| `luna-ai-bridge` | sh | AI interface v1; reports `model-not-installed` and answers from a labelled test echo backend |
| `luna-diagnostics` | sh | Summary, report file, machine-readable memory sample |
| `luna-notes` | Qt/QML app | Plain-text editor; Ctrl+S saves (default `~/Documents/notes.txt`) |
| `luna-files` | Qt/QML app | Folder browser; text files open in Notes |
| `wvkbd-mobintl` | on demand, child of the shell | On-screen keyboard, Dock button in tablet mode only |
| `luna-install` | bash, root | Installs onto a blank virtual disk (see below) |

Apps are launched in their own `app-luna-*.scope` systemd user units, so a
shell crash or restart does not kill them. `luna-shell.service` restarts on
failure at most 4 times in 60 s, then opens a failsafe terminal.

No session component runs as root. In the image, `luna-demo` has a locked
password and no sudo rights. On the live medium Casper makes it the live user
(`/etc/casper.conf`): it gets an empty password and sudo, as Ubuntu live
sessions do. Wired networks come up with DHCP (systemd-networkd, resolved).

## Installing (virtual machines only)

From a terminal in the live session, with a blank virtual disk attached:

```sh
echo 'new-password' | sudo luna-install --disk /dev/vda --user NAME
```

It erases that disk only if it has no partitions or signatures, refuses the
live medium and real hardware, and writes GPT + EFI + ext4 with GRUB on the
removable path. The new user runs the LUNA session and has sudo; the demo
account is removed. Remove the ISO and boot the disk.

## Keys

- **Ctrl+Alt+Backspace** ends the session and returns to the console. Run `luna-session` to start it again.
- **Alt+Tab** cycles windows (labwc). **Super+Return** opens a terminal.
- **Esc** closes the launcher, window overview and Control Center.

## Boot entries

- *LUNA OS R2 Live Desktop* — default.
- *LUNA OS R2 Recovery Console* — `luna.recovery=1`, no graphics, login prompt on tty1.
- *LUNA OS R2 Early Recovery (trusted console)* — initramfs shell (`break=bottom`).

## Development checks

```sh
# In the builder: offscreen render tests and helper script tests
bash tools/devroot.sh run bash -c 'cmake -S /src/r2 -B /tmp/b && cmake --build /tmp/b && ctest --test-dir /tmp/b'
# Real compositor without a VM: headless labwc driven by wlrctl/wtype
python3 r2/tests/headless_session.py /tmp/b /tmp/headless-out
```

VM tests are in `r2/tests/vm_r2.py`; see `tests/README.md`.

## Not in R2

Automatic rotation and hinge detection, pen input handling, Wi-Fi, installing
on real hardware, real power profiles, AI models, NPU runtime, Android. The UI
labels each of these as unavailable instead of simulating it.
